/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * SiHub Digital Ecosystem - Dedicated SiHub Institute Public Page Designs (5 Pages)
 * 18. Digital Skills Academy (/institute/digital-skills-academy)
 * 19. Professional & Executive Training (/institute/professional-training)
 * 20. AI & Emerging Technologies (/institute/ai-emerging)
 * 21. Research & Policy Innovation (/institute/research-innovation)
 * 22. Certification & Verification (/institute/certification)
 */

import React, { useState } from 'react';
import {
  GraduationCap,
  Award,
  Cpu,
  BookOpen,
  CheckCircle2,
  Search,
  ArrowRight,
  ShieldCheck,
  Clock,
  Sparkles,
  Download,
  Calendar,
  Layers,
  FileText,
  Binary,
  Compass,
  AlertCircle
} from 'lucide-react';
import type { DynamicPageContent } from '../DynamicCmsPage';

interface PageProps {
  page: DynamicPageContent;
  onNavigate: (url: string) => void;
}

// ---------------------------------------------------------------------------
// 18. Digital Skills Academy (/institute/digital-skills-academy)
// ---------------------------------------------------------------------------
export const DigitalSkillsAcademyPageView: React.FC<PageProps> = ({ page, onNavigate }) => {
  const courses = [
    { name: 'Full-Stack Web Development Bootcamp', duration: '16 Weeks', level: 'Beginner to Pro', modules: 'HTML/CSS, JS, React, Node, PostgreSQL' },
    { name: 'Mobile Application Engineering', duration: '12 Weeks', level: 'Intermediate', modules: 'React Native, Flutter, REST APIs, Mobile Auth' },
    { name: 'Cybersecurity Fundamentals & Defense', duration: '10 Weeks', level: 'Intermediate', modules: 'Network Security, Ethical Hacking, Linux, SIEM' },
    { name: 'UI/UX Design & Prototyping Systems', duration: '8 Weeks', level: 'All Levels', modules: 'Figma, Design Systems, User Research, Usability Testing' }
  ];

  return (
    <div className="space-y-16">
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-950 via-slate-900 to-sky-950 text-white p-8 sm:p-14 border border-slate-800 shadow-xl">
        <div className="max-w-4xl space-y-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-sky-900/60 border border-sky-700/60 text-sky-300 text-xs font-semibold uppercase tracking-wider">
            <GraduationCap className="w-3.5 h-3.5 text-sky-400" />
            <span>{page.heroBadge || 'SiHub Technical Academy'}</span>
          </div>
          <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white leading-tight">
            {page.heading || page.title || 'Digital Skills Academy'}
          </h1>
          <p className="text-base sm:text-lg text-slate-300 leading-relaxed max-w-3xl">
            {page.description || page.summary || 'Empowering the next generation of Somali software engineers, product designers, and cyber defense specialists with hands-on immersive lab training.'}
          </p>

          <div className="pt-2 flex flex-wrap gap-4">
            <button
              onClick={() => onNavigate(page.cta?.url || '/institute/digital-skills-academy/apply')}
              className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-sky-500 hover:bg-sky-400 text-slate-950 text-xs font-bold shadow-md transition-all"
            >
              <span>{page.cta?.label || 'Explore Syllabus & Enroll'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </section>

      {/* Academy Courses */}
      <section className="space-y-6">
        <div>
          <span className="text-xs font-bold text-sky-600 uppercase tracking-widest">Active Curriculum</span>
          <h2 className="text-2xl font-extrabold text-slate-900 mt-1">Bootcamp Tracks & Courses</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {courses.map((course, i) => (
            <div key={i} className="rounded-2xl bg-white p-6 border border-slate-200/90 shadow-sm hover:shadow-md transition-all flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between gap-2 mb-2">
                  <span className="text-[11px] font-bold text-sky-700 bg-sky-50 px-2.5 py-0.5 rounded-full">{course.duration}</span>
                  <span className="text-[11px] font-medium text-slate-400">{course.level}</span>
                </div>
                <h3 className="text-base font-bold text-slate-900">{course.name}</h3>
                <p className="text-xs text-slate-500 mt-2 font-mono">{course.modules}</p>
              </div>
              <div className="pt-4 mt-4 border-t border-slate-100 flex items-center justify-between text-xs">
                <span className="text-slate-500">Includes live mentor code review</span>
                <span className="font-semibold text-sky-700">Cohort Open</span>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

// ---------------------------------------------------------------------------
// 19. Professional & Executive Training (/institute/professional-training)
// ---------------------------------------------------------------------------
export const ProfessionalTrainingPageView: React.FC<PageProps> = ({ page, onNavigate }) => {
  const modules = [
    { title: 'Executive Digital Leadership', audience: 'Ministers, Directors & Board Executives', desc: 'Managing national digital transformations, digital sovereignty, and enterprise IT governance.' },
    { title: 'Data-Driven Policy Formulation', audience: 'Civil Servants & Public Policy Leads', desc: 'Harnessing statistical registries, geospatial intelligence, and predictive models for public decisions.' },
    { title: 'FinTech Regulation & Compliance', audience: 'Banking & Mobile Money Executives', desc: 'Understanding anti-money laundering, open banking APIs, and national payment switch architectures.' },
    { title: 'Enterprise Cloud Strategy', audience: 'Chief Technology Officers & IT Managers', desc: 'Cost optimization, multi-cloud disaster recovery, and sovereign data compliance.' }
  ];

  return (
    <div className="space-y-16">
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-950 via-slate-900 to-violet-950 text-white p-8 sm:p-14 border border-slate-800 shadow-xl">
        <div className="max-w-4xl space-y-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-violet-900/60 border border-violet-700/60 text-violet-300 text-xs font-semibold uppercase tracking-wider">
            <Award className="w-3.5 h-3.5 text-violet-400" />
            <span>{page.heroBadge || 'Executive Education'}</span>
          </div>
          <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white leading-tight">
            {page.heading || page.title || 'Professional & Executive Training'}
          </h1>
          <p className="text-base sm:text-lg text-slate-300 leading-relaxed max-w-3xl">
            {page.description || page.summary || 'Upskilling senior Somali leaders, enterprise decision-makers, and ministry executives with strategic digital competencies to lead institutional transformation.'}
          </p>
        </div>
      </section>

      {/* Modules */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {modules.map((m, i) => (
          <div key={i} className="rounded-2xl bg-white p-7 border border-slate-200/90 shadow-sm hover:shadow-md transition-all">
            <span className="text-[11px] font-bold text-violet-700 bg-violet-50 px-2.5 py-1 rounded-full">{m.audience}</span>
            <h3 className="text-base font-bold text-slate-900 mt-3 mb-2">{m.title}</h3>
            <p className="text-xs text-slate-600 leading-relaxed">{m.desc}</p>
          </div>
        ))}
      </section>
    </div>
  );
};

// ---------------------------------------------------------------------------
// 20. AI & Emerging Technologies (/institute/ai-emerging)
// ---------------------------------------------------------------------------
export const AiEmergingTechPageView: React.FC<PageProps> = ({ page, onNavigate }) => {
  const researchPillars = [
    { title: 'Somali Language NLP & LLM Grounding', desc: 'Developing open Somali speech-to-text datasets, semantic models, and dialectal corpora for civic services.' },
    { title: 'Satellite & Geospatial Remote Sensing', desc: 'Automated drought prediction, rangeland biomass monitoring, and flood forecasting for riverine communities.' },
    { title: 'IoT Sensors & Smart Agriculture', desc: 'Low-power LoRaWAN soil moisture probes and automated drip irrigation nodes built for Somali climates.' },
    { title: 'Edge Computing & Autonomous Drones', desc: 'Mapping rural road networks and delivering rapid medical supplies in remote regional corridors.' }
  ];

  return (
    <div className="space-y-16">
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-950 via-slate-900 to-teal-950 text-white p-8 sm:p-14 border border-slate-800 shadow-xl">
        <div className="max-w-4xl space-y-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-teal-900/60 border border-teal-700/60 text-teal-300 text-xs font-semibold uppercase tracking-wider">
            <Cpu className="w-3.5 h-3.5 text-teal-400" />
            <span>{page.heroBadge || 'Applied AI Lab'}</span>
          </div>
          <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white leading-tight">
            {page.heading || page.title || 'AI & Emerging Technologies'}
          </h1>
          <p className="text-base sm:text-lg text-slate-300 leading-relaxed max-w-3xl">
            {page.description || page.summary || 'Pioneering frontier research in artificial intelligence, computer vision, satellite sensing, and IoT sensors engineered specifically for the Somali socioeconomic context.'}
          </p>
        </div>
      </section>

      {/* Lab Pillars */}
      <section className="grid grid-cols-1 sm:grid-cols-2 gap-6">
        {researchPillars.map((p, i) => (
          <div key={i} className="rounded-2xl bg-white p-6 border border-slate-200/90 shadow-sm hover:shadow-md transition-all">
            <div className="w-10 h-10 rounded-xl bg-teal-50 text-teal-700 flex items-center justify-center mb-3">
              <Binary className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-slate-900 mb-2">{p.title}</h3>
            <p className="text-xs text-slate-600 leading-relaxed">{p.desc}</p>
          </div>
        ))}
      </section>
    </div>
  );
};

// ---------------------------------------------------------------------------
// 21. Research & Policy Innovation (/institute/research-innovation)
// ---------------------------------------------------------------------------
export const ResearchInnovationPageView: React.FC<PageProps> = ({ page, onNavigate }) => {
  const publications = [
    { title: 'The Somali Digital Economy Outlook 2025–2030', type: 'Flagship Policy Report', pages: '78 Pages', date: 'Jan 2026' },
    { title: 'Cyber Resilience Framework for Somali Financial Networks', type: 'Technical Whitepaper', pages: '42 Pages', date: 'Nov 2025' },
    { title: 'Bridging the Urban-Rural Digital Literacy Divide', type: 'Field Research Monograph', pages: '36 Pages', date: 'Aug 2025' },
    { title: 'Open Source Civic Tech for Municipal Governance', type: 'Policy Brief', pages: '24 Pages', date: 'May 2025' }
  ];

  return (
    <div className="space-y-16">
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-950 via-slate-900 to-indigo-950 text-white p-8 sm:p-14 border border-slate-800 shadow-xl">
        <div className="max-w-4xl space-y-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-900/60 border border-indigo-700/60 text-indigo-300 text-xs font-semibold uppercase tracking-wider">
            <BookOpen className="w-3.5 h-3.5 text-indigo-400" />
            <span>{page.heroBadge || 'SiHub Think Tank'}</span>
          </div>
          <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white leading-tight">
            {page.heading || page.title || 'Research & Policy Innovation'}
          </h1>
          <p className="text-base sm:text-lg text-slate-300 leading-relaxed max-w-3xl">
            {page.description || page.summary || 'Authoritative data, policy whitepapers, and rigorous analysis informing ministries, international agencies, and civil society on the evolution of Somalia’s digital landscape.'}
          </p>
        </div>
      </section>

      {/* Publications */}
      <section className="space-y-6">
        <div>
          <span className="text-xs font-bold text-indigo-600 uppercase tracking-widest">Open Knowledge Repository</span>
          <h2 className="text-2xl font-extrabold text-slate-900 mt-1">Published Policy Studies & Whitepapers</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {publications.map((pub, i) => (
            <div key={i} className="rounded-2xl bg-white p-6 border border-slate-200/90 shadow-sm hover:shadow-md transition-all flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
                  <span className="font-semibold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded">{pub.type}</span>
                  <span>{pub.date}</span>
                </div>
                <h3 className="text-base font-bold text-slate-900">{pub.title}</h3>
                <span className="text-[11px] text-slate-500 mt-1 block">{pub.pages} • Peer-Reviewed</span>
              </div>
              <div className="pt-4 mt-4 border-t border-slate-100 flex items-center justify-between text-xs">
                <span className="text-slate-400">PDF Document</span>
                <span className="inline-flex items-center gap-1 font-semibold text-indigo-600 hover:text-indigo-800">
                  <Download className="w-3.5 h-3.5" />
                  <span>Download Brief</span>
                </span>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

// ---------------------------------------------------------------------------
// 22. Certification & Verification (/institute/certification)
// ---------------------------------------------------------------------------
export const CertificationVerificationPageView: React.FC<PageProps> = ({ page }) => {
  const [certId, setCertId] = useState('');
  const [result, setResult] = useState<{ status: 'idle' | 'valid' | 'invalid'; data?: any }>({ status: 'idle' });

  const handleVerify = (e: React.FormEvent) => {
    e.preventDefault();
    if (!certId.trim()) return;
    // Demonstration verification simulator
    if (certId.toUpperCase().startsWith('SIHUB-') || certId.length > 5) {
      setResult({
        status: 'valid',
        data: {
          id: certId.toUpperCase(),
          recipient: 'Verified SiHub Academy Graduate',
          track: 'Full-Stack Software Engineering Bootcamp',
          issueDate: 'October 15, 2025',
          credentialStatus: 'Active & Cryptographically Verified'
        }
      });
    } else {
      setResult({ status: 'invalid' });
    }
  };

  return (
    <div className="space-y-16">
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-950 via-slate-900 to-blue-950 text-white p-8 sm:p-14 border border-slate-800 shadow-xl">
        <div className="max-w-4xl space-y-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-900/60 border border-blue-700/60 text-blue-300 text-xs font-semibold uppercase tracking-wider">
            <ShieldCheck className="w-3.5 h-3.5 text-blue-400" />
            <span>{page.heroBadge || 'Tamper-Proof Credential Registry'}</span>
          </div>
          <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white leading-tight">
            {page.heading || page.title || 'Certification & Credential Verification'}
          </h1>
          <p className="text-base sm:text-lg text-slate-300 leading-relaxed max-w-3xl">
            {page.description || page.summary || 'Verify the cryptographic authenticity of any diploma, fellowship certificate, or micro-credential issued by the Somali Innovation Hub Institute.'}
          </p>
        </div>
      </section>

      {/* Verification Portal */}
      <section className="max-w-3xl mx-auto rounded-3xl bg-white p-8 sm:p-10 border border-slate-200/90 shadow-sm space-y-6">
        <div>
          <h2 className="text-xl font-bold text-slate-900">Enter Certificate Serial Number</h2>
          <p className="text-xs text-slate-500 mt-1">Found on the bottom-right corner or QR link of any SiHub credential (e.g. SIHUB-2025-DEV-4819)</p>
        </div>

        <form onSubmit={handleVerify} className="flex flex-col sm:flex-row gap-3">
          <input
            type="text"
            value={certId}
            onChange={(e) => setCertId(e.target.value)}
            placeholder="e.g. SIHUB-2025-DEV-4819"
            className="flex-1 px-4 py-3 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-600 text-sm font-mono uppercase"
          />
          <button
            type="submit"
            className="px-6 py-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-sm transition-all"
          >
            Verify Credential
          </button>
        </form>

        {result.status === 'valid' && (
          <div className="p-5 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-900 space-y-2">
            <div className="flex items-center gap-2 text-emerald-700 font-bold text-sm">
              <CheckCircle2 className="w-5 h-5" />
              <span>Official Credential Verified</span>
            </div>
            <div className="text-xs space-y-1 pt-2">
              <p><strong>Credential ID:</strong> {result.data?.id}</p>
              <p><strong>Programme:</strong> {result.data?.track}</p>
              <p><strong>Issuance Date:</strong> {result.data?.issueDate}</p>
              <p><strong>Status:</strong> <span className="text-emerald-700 font-semibold">{result.data?.credentialStatus}</span></p>
            </div>
          </div>
        )}

        {result.status === 'invalid' && (
          <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
            <span>No matching credential found. Please verify the serial number format and re-enter.</span>
          </div>
        )}
      </section>
    </div>
  );
};
