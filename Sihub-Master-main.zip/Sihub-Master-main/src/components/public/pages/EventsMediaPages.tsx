/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * SiHub Digital Ecosystem - Dedicated Events & Media Public Page Designs (5 Pages)
 * 23. SiTalks (/events/sitalks)
 * 24. Annual Somali Innovation Summit (/events/summit)
 * 25. Innovation Expo & Demo Day (/events/expo)
 * 26. Ecosystem News & Stories (/events/news-stories)
 * 27. Media Gallery & Brand Assets (/events/media)
 */

import React from 'react';
import {
  Mic,
  Calendar,
  Sparkles,
  MapPin,
  Clock,
  ArrowRight,
  Play,
  Download,
  Image as ImageIcon,
  Video,
  FileText,
  Radio,
  Share2,
  Tv,
  Layers,
  CheckCircle2,
  Users
} from 'lucide-react';
import type { DynamicPageContent } from '../DynamicCmsPage';

interface PageProps {
  page: DynamicPageContent;
  onNavigate: (url: string) => void;
}

// ---------------------------------------------------------------------------
// 23. SiTalks (/events/sitalks)
// ---------------------------------------------------------------------------
export const SiTalksPageView: React.FC<PageProps> = ({ page, onNavigate }) => {
  const episodes = [
    { title: 'The Next Billion-Dollar Somali Startup: FinTech Horizons', speaker: 'Eng. Abdullahi Hassan', role: 'Head of Mobile Money Infrastructure', date: 'Feb 12, 2026', duration: '48 Mins' },
    { title: 'Artificial Intelligence & Civic Governance in Mogadishu', speaker: 'Dr. Khadija Ali', role: 'Lead Data Scientist', date: 'Jan 28, 2026', duration: '52 Mins' },
    { title: 'Green Energy Off-Grid Grids: Powering Somali Nomadic Communities', speaker: 'Mohamed Abukar', role: 'CleanTech Innovator', date: 'Dec 14, 2025', duration: '41 Mins' }
  ];

  return (
    <div className="space-y-16">
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-950 via-slate-900 to-rose-950 text-white p-8 sm:p-14 border border-slate-800 shadow-xl">
        <div className="max-w-4xl space-y-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-900/60 border border-rose-700/60 text-rose-300 text-xs font-semibold uppercase tracking-wider">
            <Mic className="w-3.5 h-3.5 text-rose-400" />
            <span>{page.heroBadge || 'Flagship Thought-Leadership Forum'}</span>
          </div>
          <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white leading-tight">
            {page.heading || page.title || 'SiTalks: Voices of Innovation'}
          </h1>
          <p className="text-base sm:text-lg text-slate-300 leading-relaxed max-w-3xl">
            {page.description || page.summary || 'Monthly fireside conversations, recorded keynotes, and provocative debates with the thinkers, founders, and policy-makers defining the Somali digital renaissance.'}
          </p>

          <div className="pt-2 flex flex-wrap gap-4">
            <button
              onClick={() => onNavigate('/events/sitalks/register')}
              className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold shadow-md transition-all"
            >
              <span>Attend Next Session</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </section>

      {/* Recent Episodes */}
      <section className="space-y-6">
        <div>
          <span className="text-xs font-bold text-rose-600 uppercase tracking-widest">Media Archive</span>
          <h2 className="text-2xl font-extrabold text-slate-900 mt-1">Recorded SiTalks Sessions</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {episodes.map((ep, i) => (
            <div key={i} className="rounded-2xl bg-white border border-slate-200/90 shadow-sm overflow-hidden flex flex-col justify-between hover:shadow-md transition-all">
              <div className="h-44 bg-slate-900 flex items-center justify-center relative group cursor-pointer">
                <div className="w-12 h-12 rounded-full bg-rose-600 text-white flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
                  <Play className="w-5 h-5 ml-0.5" />
                </div>
                <span className="absolute bottom-2 right-2 text-[10px] font-mono bg-black/70 text-white px-2 py-0.5 rounded">
                  {ep.duration}
                </span>
              </div>
              <div className="p-5 space-y-2">
                <div className="text-[11px] text-slate-400">{ep.date}</div>
                <h3 className="text-sm font-bold text-slate-900 line-clamp-2">{ep.title}</h3>
                <p className="text-xs text-slate-500">{ep.speaker} • {ep.role}</p>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

// ---------------------------------------------------------------------------
// 24. Annual Somali Innovation Summit (/events/summit)
// ---------------------------------------------------------------------------
export const SummitPageView: React.FC<PageProps> = ({ page, onNavigate }) => {
  const tracks = [
    { name: 'National Digital Sovereignty Track', topics: 'Identity systems, telecommunications act, sovereign cloud data centers.' },
    { name: 'Pan-Somali Venture Capital Arena', topics: 'Diaspora angel syndicates, institutional seed funds, cross-border remittance fintech.' },
    { name: 'Climate Resilience & AgriTech Forum', topics: 'Satellite remote sensing, micro-irrigation, regenerative rangeland tech.' },
    { name: 'Emerging AI & Frontier Tech Symposium', topics: 'Somali LLM datasets, civic automation, youth engineering workforce.' }
  ];

  return (
    <div className="space-y-16">
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-950 via-slate-900 to-amber-950 text-white p-8 sm:p-14 border border-slate-800 shadow-xl">
        <div className="max-w-4xl space-y-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-900/60 border border-amber-700/60 text-amber-300 text-xs font-semibold uppercase tracking-wider">
            <Calendar className="w-3.5 h-3.5 text-amber-400" />
            <span>{page.heroBadge || 'National Flagship Summit'}</span>
          </div>
          <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white leading-tight">
            {page.heading || page.title || 'Somali Innovation Summit 2026'}
          </h1>
          <p className="text-base sm:text-lg text-slate-300 leading-relaxed max-w-3xl">
            {page.description || page.summary || 'Somalia’s preeminent annual tech gathering convening 2,000+ founders, ministers, diaspora investors, multilateral partners, and youth innovators under one roof.'}
          </p>

          <div className="flex flex-wrap items-center gap-6 text-xs text-slate-300 pt-2">
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4 text-amber-400" />
              <span>November 18–20, 2026</span>
            </div>
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4 text-amber-400" />
              <span>Mogadishu International Conference Centre</span>
            </div>
          </div>

          <div className="pt-2 flex flex-wrap gap-4">
            <button
              onClick={() => onNavigate(page.cta?.url || '/events/summit/register')}
              className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold shadow-md transition-all"
            >
              <span>{page.cta?.label || 'Register for Delegate Pass'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </section>

      {/* Summit Tracks */}
      <section className="space-y-6">
        <div>
          <span className="text-xs font-bold text-amber-600 uppercase tracking-widest">Summit Agenda</span>
          <h2 className="text-2xl font-extrabold text-slate-900 mt-1">4 Curated Thematic Tracks</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {tracks.map((t, i) => (
            <div key={i} className="rounded-2xl bg-white p-6 border border-slate-200/90 shadow-sm hover:shadow-md transition-all">
              <h3 className="text-base font-bold text-slate-900 mb-2">{t.name}</h3>
              <p className="text-xs text-slate-600 leading-relaxed">{t.topics}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

// ---------------------------------------------------------------------------
// 25. Innovation Expo & Demo Day (/events/expo)
// ---------------------------------------------------------------------------
export const ExpoPageView: React.FC<PageProps> = ({ page, onNavigate }) => {
  const pavilions = [
    { name: 'Hardware & Prototyping Pavilion', count: '18 Startups', focus: 'Drones, 3D printing, solar IoT rigs, robotics kits' },
    { name: 'FinTech & Digital Commerce Pavilion', count: '24 Startups', focus: 'USSD payments, remittance aggregators, credit rating tools' },
    { name: 'EdTech & Digital Inclusion Pavilion', count: '14 Startups', focus: 'Offline educational tablets, Somali language ed-apps' },
    { name: 'ClimateTech & Food Security Pavilion', count: '16 Startups', focus: 'Smart greenhousing, hydroponics, fisheries traceability' }
  ];

  return (
    <div className="space-y-16">
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-950 via-slate-900 to-fuchsia-950 text-white p-8 sm:p-14 border border-slate-800 shadow-xl">
        <div className="max-w-4xl space-y-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-fuchsia-900/60 border border-fuchsia-700/60 text-fuchsia-300 text-xs font-semibold uppercase tracking-wider">
            <Sparkles className="w-3.5 h-3.5 text-fuchsia-400" />
            <span>{page.heroBadge || 'Exhibition & Pitch Arena'}</span>
          </div>
          <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white leading-tight">
            {page.heading || page.title || 'Innovation Expo & Demo Day'}
          </h1>
          <p className="text-base sm:text-lg text-slate-300 leading-relaxed max-w-3xl">
            {page.description || page.summary || 'Live hardware prototypes, interactive software demos, and high-stakes startup pitch battles before regional venture funds and corporate procurement leads.'}
          </p>

          <div className="pt-2 flex flex-wrap gap-4">
            <button
              onClick={() => onNavigate('/events/expo/booth')}
              className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-fuchsia-600 hover:bg-fuchsia-500 text-white text-xs font-bold shadow-md transition-all"
            >
              <span>Reserve Startup Booth</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </section>

      {/* Expo Pavilions */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {pavilions.map((p, i) => (
          <div key={i} className="rounded-2xl bg-white p-6 border border-slate-200/90 shadow-sm hover:shadow-md transition-all">
            <div className="flex items-center justify-between text-xs mb-2">
              <span className="font-bold text-fuchsia-700 bg-fuchsia-50 px-2 py-0.5 rounded">{p.count}</span>
            </div>
            <h3 className="text-base font-bold text-slate-900 mb-1">{p.name}</h3>
            <p className="text-xs text-slate-600 leading-relaxed">{p.focus}</p>
          </div>
        ))}
      </section>
    </div>
  );
};

// ---------------------------------------------------------------------------
// 26. Ecosystem News & Stories (/events/news-stories)
// ---------------------------------------------------------------------------
export const NewsStoriesPageView: React.FC<PageProps> = ({ page, onNavigate }) => {
  const articles = [
    { title: 'SiHub Closes $1.5M Seed Window with International Partners', tag: 'Funding', date: 'February 10, 2026', readTime: '4 min read' },
    { title: 'Over 2,400 Young Women Graduate from Somali Women In Tech Cohort 4', tag: 'Education', date: 'January 22, 2026', readTime: '3 min read' },
    { title: 'New Satellite Lab in Garowe Deploys 50 Soil Sensing Probes', tag: 'AgriTech', date: 'December 18, 2025', readTime: '5 min read' }
  ];

  return (
    <div className="space-y-16">
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-950 via-slate-900 to-blue-950 text-white p-8 sm:p-14 border border-slate-800 shadow-xl">
        <div className="max-w-4xl space-y-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-900/60 border border-blue-700/60 text-blue-300 text-xs font-semibold uppercase tracking-wider">
            <FileText className="w-3.5 h-3.5 text-blue-400" />
            <span>{page.heroBadge || 'Official Newsroom'}</span>
          </div>
          <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white leading-tight">
            {page.heading || page.title || 'Ecosystem News & Impact Stories'}
          </h1>
          <p className="text-base sm:text-lg text-slate-300 leading-relaxed max-w-3xl">
            {page.description || page.summary || 'Authoritative dispatches, press releases, program graduations, and deep-dive journalistic reporting from across the SiHub nationwide network.'}
          </p>
        </div>
      </section>

      {/* Articles */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {articles.map((art, i) => (
          <div key={i} className="rounded-2xl bg-white p-6 border border-slate-200/90 shadow-sm hover:shadow-md transition-all flex flex-col justify-between">
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span className="font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded">{art.tag}</span>
                <span>{art.readTime}</span>
              </div>
              <h3 className="text-base font-bold text-slate-900 mt-2">{art.title}</h3>
            </div>
            <div className="pt-4 mt-4 border-t border-slate-100 text-xs text-slate-500">
              {art.date}
            </div>
          </div>
        ))}
      </section>
    </div>
  );
};

// ---------------------------------------------------------------------------
// 27. Media Gallery & Brand Assets (/events/media)
// ---------------------------------------------------------------------------
export const MediaGalleryPageView: React.FC<PageProps> = ({ page }) => {
  const assets = [
    { title: 'Official SiHub Master Logos (SVG, PNG, EPS)', size: '24 MB ZIP', type: 'Vector Kit' },
    { title: 'Brand Guidelines & Typography Specification 2026', size: '12 MB PDF', type: 'Brand Book' },
    { title: 'High-Res Campus & Tech Lab Photo Archive', size: '180 MB ZIP', type: 'Photo Library' },
    { title: 'Executive Headshots & Leadership Bios', size: '32 MB ZIP', type: 'Media Press Kit' }
  ];

  return (
    <div className="space-y-16">
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-950 via-slate-900 to-indigo-950 text-white p-8 sm:p-14 border border-slate-800 shadow-xl">
        <div className="max-w-4xl space-y-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-900/60 border border-indigo-700/60 text-indigo-300 text-xs font-semibold uppercase tracking-wider">
            <ImageIcon className="w-3.5 h-3.5 text-indigo-400" />
            <span>{page.heroBadge || 'Media Kit & Brand Center'}</span>
          </div>
          <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white leading-tight">
            {page.heading || page.title || 'Media Gallery & Brand Assets'}
          </h1>
          <p className="text-base sm:text-lg text-slate-300 leading-relaxed max-w-3xl">
            {page.description || page.summary || 'Official brand identities, high-resolution photography, institutional color palettes, and press-ready media kits for journalists and partners.'}
          </p>
        </div>
      </section>

      {/* Asset Downloads */}
      <section className="space-y-6">
        <div>
          <span className="text-xs font-bold text-indigo-600 uppercase tracking-widest">Digital Brand Assets</span>
          <h2 className="text-2xl font-extrabold text-slate-900 mt-1">Downloadable Press Kits</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {assets.map((asset, i) => (
            <div key={i} className="rounded-2xl bg-white p-6 border border-slate-200/90 shadow-sm hover:shadow-md transition-all flex items-center justify-between">
              <div>
                <span className="text-[10px] font-bold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded">{asset.type}</span>
                <h3 className="text-sm font-bold text-slate-900 mt-1">{asset.title}</h3>
                <span className="text-xs text-slate-400">{asset.size}</span>
              </div>
              <button className="p-3 rounded-xl bg-slate-100 hover:bg-indigo-50 text-slate-700 hover:text-indigo-700 transition-colors">
                <Download className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};
