/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * SiHub Digital Ecosystem - Dedicated Our Impact Public Page Designs (4 Pages)
 * 28. Success Stories (/impact/success-stories)
 * 29. Projects & Achievements (/impact/projects-achievements)
 * 30. Annual Reports (/impact/annual-reports)
 * 31. Community Impact (/impact/community-impact)
 */

import React from 'react';
import {
  TrendingUp,
  CheckCircle2,
  FileText,
  Users,
  Award,
  Download,
  ArrowRight,
  ShieldCheck,
  Building2,
  Globe2,
  Heart,
  BarChart3,
  Layers,
  Sparkles
} from 'lucide-react';
import type { DynamicPageContent } from '../DynamicCmsPage';

interface PageProps {
  page: DynamicPageContent;
  onNavigate: (url: string) => void;
}

// ---------------------------------------------------------------------------
// 28. Success Stories (/impact/success-stories)
// ---------------------------------------------------------------------------
export const SuccessStoriesPageView: React.FC<PageProps> = ({ page, onNavigate }) => {
  const stories = [
    {
      title: 'From Self-Taught Coder to Lead Fintech Architect',
      name: 'Mohamed Yasin',
      role: 'Alum, Digital Skills Academy',
      quote: 'SiHub did not just teach me how to write code; they connected me with live production projects and verified mentorship that completely transformed my career trajectory.',
      metric: 'Employed at Regional Bank'
    },
    {
      title: 'Solar Smart-Cold Hubs Saving 40% of Coastal Fish Catches',
      name: 'Sahra Nur',
      role: 'Founder, Kismayo BlueCool',
      quote: 'With $20,000 in SiHub seed grant funding and mechanical engineering lab support, our cold micro-storage now powers 60 fishing families every day.',
      metric: '$85K Annual Local Revenue'
    },
    {
      title: 'Empowering 400 Nomadic Girls with Offline Learning Tablets',
      name: 'Halima Adan',
      role: 'Civic Innovator & Teacher',
      quote: 'Bringing solar-charged digital reading devices into pastoralist camps proved that digital inclusion has no geographical boundaries in Somalia.',
      metric: '400+ Active Students'
    }
  ];

  return (
    <div className="space-y-16">
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-950 via-slate-900 to-emerald-950 text-white p-8 sm:p-14 border border-slate-800 shadow-xl">
        <div className="max-w-4xl space-y-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-900/60 border border-emerald-700/60 text-emerald-300 text-xs font-semibold uppercase tracking-wider">
            <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
            <span>{page.heroBadge || 'Human Impact Stories'}</span>
          </div>
          <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white leading-tight">
            {page.heading || page.title || 'Somali Tech Success Stories'}
          </h1>
          <p className="text-base sm:text-lg text-slate-300 leading-relaxed max-w-3xl">
            {page.description || page.summary || 'Real journeys of young Somali engineers, women founders, and community champions whose lives and communities have been transformed through SiHub programs.'}
          </p>
        </div>
      </section>

      {/* Stories Grid */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {stories.map((s, i) => (
          <div key={i} className="rounded-2xl bg-white p-7 border border-slate-200/90 shadow-sm hover:shadow-md transition-all flex flex-col justify-between">
            <div className="space-y-4">
              <span className="text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full">
                {s.metric}
              </span>
              <h3 className="text-base font-bold text-slate-900 leading-snug">{s.title}</h3>
              <p className="text-xs text-slate-600 italic leading-relaxed">"{s.quote}"</p>
            </div>
            <div className="pt-4 mt-4 border-t border-slate-100">
              <h4 className="text-xs font-bold text-slate-900">{s.name}</h4>
              <p className="text-[11px] text-slate-400">{s.role}</p>
            </div>
          </div>
        ))}
      </section>
    </div>
  );
};

// ---------------------------------------------------------------------------
// 29. Projects & Achievements (/impact/projects-achievements)
// ---------------------------------------------------------------------------
export const ProjectsAchievementsPageView: React.FC<PageProps> = ({ page }) => {
  const achievements = [
    { metric: '14,200+', label: 'Graduates Certified', desc: 'Directly trained in modern programming, cloud systems, and data analytics across all states.' },
    { metric: '184', label: 'Startups Accelerated', desc: 'Early-stage tech startups incubated with prototyping resources and pitch readiness.' },
    { metric: '$2.8M+', label: 'Seed Capital Mobilized', desc: 'Non-dilutive grants and investor seed checks deployed directly into Somali venture founders.' },
    { metric: '48%', label: 'Female Participation', desc: 'High gender inclusion achieved through dedicated women-in-tech pathways and family-friendly labs.' }
  ];

  return (
    <div className="space-y-16">
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-950 via-slate-900 to-cyan-950 text-white p-8 sm:p-14 border border-slate-800 shadow-xl">
        <div className="max-w-4xl space-y-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-900/60 border border-cyan-700/60 text-cyan-300 text-xs font-semibold uppercase tracking-wider">
            <BarChart3 className="w-3.5 h-3.5 text-cyan-400" />
            <span>{page.heroBadge || 'Verified Milestones'}</span>
          </div>
          <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white leading-tight">
            {page.heading || page.title || 'Projects & Ecosystem Achievements'}
          </h1>
          <p className="text-base sm:text-lg text-slate-300 leading-relaxed max-w-3xl">
            {page.description || page.summary || 'A transparent, data-driven account of national development deliverables, digital infrastructure milestones, and measurable community outcomes.'}
          </p>
        </div>
      </section>

      {/* KPI Cards */}
      <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {achievements.map((ach, i) => (
          <div key={i} className="rounded-2xl bg-white p-6 border border-slate-200/90 shadow-sm hover:shadow-md transition-all text-center">
            <div className="text-3xl sm:text-4xl font-extrabold text-cyan-800 tracking-tight">{ach.metric}</div>
            <h3 className="text-sm font-bold text-slate-900 mt-2 mb-1">{ach.label}</h3>
            <p className="text-xs text-slate-500 leading-relaxed">{ach.desc}</p>
          </div>
        ))}
      </section>
    </div>
  );
};

// ---------------------------------------------------------------------------
// 30. Annual Reports (/impact/annual-reports)
// ---------------------------------------------------------------------------
export const AnnualReportsPageView: React.FC<PageProps> = ({ page }) => {
  const reports = [
    { year: '2025 Annual Impact & Audit Report', size: '18.4 MB PDF', pages: '84 Pages', auditedBy: 'International Certified Audit' },
    { year: '2024 Ecosystem Progress Monograph', size: '14.2 MB PDF', pages: '68 Pages', auditedBy: 'Verified Public Filing' },
    { year: '2023 Founding Phase Retrospective', size: '9.8 MB PDF', pages: '52 Pages', auditedBy: 'Audited Financial Statements' }
  ];

  return (
    <div className="space-y-16">
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-950 via-slate-900 to-blue-950 text-white p-8 sm:p-14 border border-slate-800 shadow-xl">
        <div className="max-w-4xl space-y-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-900/60 border border-blue-700/60 text-blue-300 text-xs font-semibold uppercase tracking-wider">
            <FileText className="w-3.5 h-3.5 text-blue-400" />
            <span>{page.heroBadge || 'Governance & Accountability'}</span>
          </div>
          <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white leading-tight">
            {page.heading || page.title || 'Annual Reports & Audited Filings'}
          </h1>
          <p className="text-base sm:text-lg text-slate-300 leading-relaxed max-w-3xl">
            {page.description || page.summary || 'Full institutional transparency, governance disclosures, and audited financial statements published annually for our partners, donors, and the Somali public.'}
          </p>
        </div>
      </section>

      {/* Reports */}
      <section className="space-y-4 max-w-3xl mx-auto">
        {reports.map((rep, i) => (
          <div key={i} className="rounded-2xl bg-white p-6 border border-slate-200/90 shadow-sm flex items-center justify-between gap-4 hover:shadow-md transition-all">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center shrink-0">
                <FileText className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900">{rep.year}</h3>
                <p className="text-xs text-slate-500 mt-0.5">{rep.pages} • {rep.auditedBy} • {rep.size}</p>
              </div>
            </div>
            <button className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-slate-100 hover:bg-blue-50 text-slate-700 hover:text-blue-700 text-xs font-bold transition-colors">
              <Download className="w-3.5 h-3.5" />
              <span>Download PDF</span>
            </button>
          </div>
        ))}
      </section>
    </div>
  );
};

// ---------------------------------------------------------------------------
// 31. Community Impact (/impact/community-impact)
// ---------------------------------------------------------------------------
export const CommunityImpactPageView: React.FC<PageProps> = ({ page }) => {
  const impacts = [
    { title: 'Grassroots Coding Clubs in Secondary Schools', desc: 'Over 60 high schools across Banadir, Puntland, and Jubaland equipped with curriculum and student clubs.' },
    { title: 'Community Maker & Repair Cafes', desc: 'Free public workshops teaching local youth electronics repair, solar battery refurbishment, and 3D printing.' },
    { title: 'Accessible Assistive Tech for People with Disabilities', desc: 'Custom Somali braille screen-readers and ergonomic assistive devices prototyped at our makerspace.' }
  ];

  return (
    <div className="space-y-16">
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-950 via-slate-900 to-indigo-950 text-white p-8 sm:p-14 border border-slate-800 shadow-xl">
        <div className="max-w-4xl space-y-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-900/60 border border-indigo-700/60 text-indigo-300 text-xs font-semibold uppercase tracking-wider">
            <Heart className="w-3.5 h-3.5 text-indigo-400" />
            <span>{page.heroBadge || 'Grassroots Transformation'}</span>
          </div>
          <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white leading-tight">
            {page.heading || page.title || 'Community Impact & Social Inclusion'}
          </h1>
          <p className="text-base sm:text-lg text-slate-300 leading-relaxed max-w-3xl">
            {page.description || page.summary || 'Ensuring technological progress is deeply inclusive, rooted in community benefit, and accessible to vulnerable and rural Somali populations.'}
          </p>
        </div>
      </section>

      {/* Community Grid */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {impacts.map((imp, i) => (
          <div key={i} className="rounded-2xl bg-white p-6 border border-slate-200/90 shadow-sm hover:shadow-md transition-all">
            <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-700 flex items-center justify-center mb-4">
              <Users className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-slate-900 mb-2">{imp.title}</h3>
            <p className="text-xs text-slate-600 leading-relaxed">{imp.desc}</p>
          </div>
        ))}
      </section>
    </div>
  );
};
